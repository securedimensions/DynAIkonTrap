__version__ = '2.7.0'
__git_version__ = '0.6.0-113595-g8c6d9ae'
